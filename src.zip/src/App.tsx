import Home from './pages/Home';
import MoodPrompt from './components/MoodPrompt';

function App() {
  return (
    <div className="container">
      <h1>🎬 Movie Explorer</h1>
      <MoodPrompt />
      <Home />
    </div>
  );
}



export default App;
