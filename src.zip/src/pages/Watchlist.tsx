const Watchlist = () => {
  return (
    <div>
      <h2>Your Watchlist</h2>
      <p>(This page will show saved movies)</p>
    </div>
  );
};

export default Watchlist;
