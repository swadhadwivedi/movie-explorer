import { useState } from 'react';
import { getMovieRecommendations } from '../api/genai';

const MoodPrompt = () => {
  const [input, setInput] = useState('');
  const [response, setResponse] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    setLoading(true);
    try {
      const result = await getMovieRecommendations(input);
      setResponse(result);
    } catch (err) {
      setResponse("Error fetching recommendation.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ marginTop: "40px" }}>
      <h2>🎭 Movie Mood Recommender</h2>
      <input
        type="text"
        placeholder="e.g., I'm in the mood for a cozy rainy movie"
        value={input}
        onChange={(e) => setInput(e.target.value)}
        style={{ padding: '12px', width: '100%', marginBottom: '10px' }}
      />
      <button onClick={handleSubmit} disabled={loading}>
        {loading ? 'Thinking...' : 'Get Suggestions'}
      </button>
      <div style={{ marginTop: '20px', whiteSpace: 'pre-wrap' }}>{response}</div>
    </div>
  );
};

export default MoodPrompt;
