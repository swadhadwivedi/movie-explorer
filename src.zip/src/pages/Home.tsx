import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { fetchMovies } from '../api/tmdb';
import MovieCard from '../components/MovieCard';
import SearchBar from '../components/SearchBar';
import Loader from '../components/Loader';
import { useDebounce } from '../hooks/useDebounce';

const Home = () => {
  const [query, setQuery] = useState('avengers');
  const debouncedQuery = useDebounce(query, 500);

  const { data, isLoading } = useQuery({
    queryKey: ['movies', debouncedQuery],
    queryFn: () => fetchMovies(debouncedQuery),
    enabled: !!debouncedQuery,
  });

  return (
    <div>
      <SearchBar value={query} onChange={setQuery} />
      {isLoading ? (
        <Loader />
      ) : (
        <div className="movie-grid">
          {data?.results.map((movie) => (
            <MovieCard key={movie.id} movie={movie} />
          ))}
        </div>
      )}
    </div>
  );
};

export default Home;
